globalThis.__dshPowerdeskChunks__ = globalThis.__dshPowerdeskChunks__ || {};
globalThis.__dshPowerdeskChunks__["ext:hello-powerdesk"] = (require) => {
	var module = { exports: {} };
	module.exports;
	let react = require("react");
	let react_jsx_runtime = require("react/jsx-runtime");
	//#region src/index.tsx
	/**
	* Hello Powerdesk — a minimal example extension that proves the whole
	* extension contract works end to end.
	*
	* It mounts as a sidebar tab and exercises everything an extension needs to:
	*  - receives its {@link TabComponentProps} (scope + visibility),
	*  - uses React hooks (useState — proves the host's React is shared, not a
	*    bundled second copy that would throw on every hook call),
	*  - reads DSH theme tokens (so it follows the user's light/dark choice),
	*  - renders an interactive counter (proves events + re-render work).
	*
	* If this renders and the button counts up when clicked, the extension
	* pipeline is healthy: upload → unpack → manifest parse → chunk load → tab
	* register → mount → props → hooks → render.
	*/
	function HelloPowerdesk({ scope, tab, visible }) {
		const [count, setCount] = (0, react.useState)(0);
		const mounted = (0, react.useState)(() => Date.now())[0];
		return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
			style: {
				padding: 16,
				display: "flex",
				flexDirection: "column",
				gap: 12,
				height: "100%",
				boxSizing: "border-box",
				overflow: "auto"
			},
			children: [
				/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("header", {
					style: {
						display: "flex",
						flexDirection: "column",
						gap: 2
					},
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("h3", {
						style: {
							margin: 0,
							font: "var(--dsw-font-s-strong-14)",
							color: "var(--dsw-alias-label-primary)",
							display: "flex",
							alignItems: "center",
							gap: 6
						},
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							children: "👋"
						}), " Hello Powerdesk"]
					}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						style: {
							margin: 0,
							font: "var(--dsw-font-xxs-12)",
							color: "var(--dsw-alias-label-tertiary)"
						},
						children: "A minimal example extension — if you can read this and the button counts up, the extension pipeline works."
					})]
				}),
				/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("section", {
					style: {
						display: "flex",
						flexDirection: "column",
						gap: 6,
						padding: 10,
						borderRadius: 8,
						border: "1px solid var(--dsw-alias-border-l1)",
						background: "var(--dsw-alias-bg-layer-1)"
					},
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Row, {
							label: "tab id",
							value: tab.id
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Row, {
							label: "tab type",
							value: tab.type
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Row, {
							label: "session",
							value: scope.sessionId,
							mono: true
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Row, {
							label: "cwd",
							value: scope.cwd ?? "(none)",
							mono: true
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Row, {
							label: "visible",
							value: visible ? "yes" : "no",
							tone: visible ? "success" : "muted"
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Row, {
							label: "mounted at",
							value: new Date(mounted).toLocaleTimeString(),
							mono: true
						})
					]
				}),
				/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					style: {
						display: "flex",
						alignItems: "center",
						gap: 10
					},
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setCount((n) => n + 1);
						},
						style: {
							padding: "6px 12px",
							borderRadius: 8,
							border: "1px solid var(--dsw-alias-border-l2)",
							background: "var(--dsw-alias-bg-layer-1)",
							color: "var(--dsw-alias-label-primary)",
							cursor: "pointer",
							font: "var(--dsw-font-s-14)"
						},
						children: [
							"clicked ",
							count,
							" ",
							count === 1 ? "time" : "times"
						]
					}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							setCount(0);
						},
						style: {
							padding: "6px 10px",
							borderRadius: 8,
							border: "1px solid var(--dsw-alias-border-l1)",
							background: "transparent",
							color: "var(--dsw-alias-label-tertiary)",
							cursor: "pointer",
							font: "var(--dsw-font-xxs-12)"
						},
						children: "reset"
					})]
				})
			]
		});
	}
	/** One label/value row, using theme tokens. `tone` tints the value. */
	function Row({ label, value, mono, tone }) {
		return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				gap: 8,
				alignItems: "baseline",
				minWidth: 0
			},
			children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
				style: {
					flex: "none",
					width: 64,
					font: "var(--dsw-font-xxs-12)",
					color: "var(--dsw-alias-label-tertiary)"
				},
				children: label
			}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
				style: {
					minWidth: 0,
					font: mono ? "var(--dsw-font-markdown-code-block-small)" : "var(--dsw-font-xxs-12)",
					color: tone === "success" ? "var(--dsw-alias-state-success-primary)" : tone === "muted" ? "var(--dsw-alias-label-tertiary)" : "var(--dsw-alias-label-secondary)",
					whiteSpace: "nowrap",
					overflow: "hidden",
					textOverflow: "ellipsis"
				},
				title: value,
				children: value
			})]
		});
	}
	//#endregion
	module.exports = HelloPowerdesk;
	return module.exports;
};

//# sourceMappingURL=bundle.js.map